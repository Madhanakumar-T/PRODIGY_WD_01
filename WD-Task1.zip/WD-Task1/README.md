# responsive-navbar-css-js

A simple navbar built with CSS and Javascript. 
watch video tutorial if you want to follow along :)

https://www.youtube.com/watch?v=nR6IQad9PEg
